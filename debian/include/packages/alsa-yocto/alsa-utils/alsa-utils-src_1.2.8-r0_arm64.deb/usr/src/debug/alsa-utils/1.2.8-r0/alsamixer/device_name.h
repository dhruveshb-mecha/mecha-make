#ifndef DEVICE_NAME_FORM_H_INCLUDED
#define DEVICE_NAME_FORM_H_INCLUDED

void create_device_name_form(void);

#endif
